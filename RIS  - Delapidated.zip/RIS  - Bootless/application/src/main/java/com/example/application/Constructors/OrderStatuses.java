package com.example.application.Constructors;

public class OrderStatuses {

    String Orderstatus;

    public OrderStatuses(String Orderstatus) {
        this.Orderstatus = Orderstatus;
    }

    public String getOrderstatus() {

        return Orderstatus;
    }

}
