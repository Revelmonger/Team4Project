
import com.example.application.FXApp;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author Chase
 */
public class RUNTHIS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
FXApp.main1(args);
    }
    
}
