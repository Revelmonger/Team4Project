package com.example.application.Constructors;

public class Radiologists {

    String string;
    Integer int1;

    public Radiologists(int int1, String string) {
        this.string = string;
        this.int1 = int1;
    }

    public String getRadiologistName() {
        return string;
    }

}
