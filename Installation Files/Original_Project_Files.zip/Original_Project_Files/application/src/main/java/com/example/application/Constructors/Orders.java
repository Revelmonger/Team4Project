package com.example.application.Constructors;

public class Orders {

    Integer int1;
    public Orders(int int1) {
        this.int1 = int1;
    }


    public Integer getOrders() {

        return int1;
    }


}
